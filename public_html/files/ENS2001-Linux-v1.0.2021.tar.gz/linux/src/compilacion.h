//compilacion.h

#ifndef _COMPILACION_H_
#define _COMPILACION_H_

//Para evitar el error Stack Overflow
#define YYMAXDEPTH 2000000

//VERSIÓN Linux

#define _ENS2001_LINUX_
#define _CADENAS_H_ "cadenas_ansi.h"
#define TITULO "ENS2001 para Linux"
#define VERSION "1.0"
#define FECHA "Febrero 2003 (recompilado en Mayo 2021)"
#define URL "https://ens2001.falvarez.es/"
#define _IDIOMA_ESPANOL_

#endif //_COMPILACION_H_
